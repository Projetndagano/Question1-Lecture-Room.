/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bd.mavenproject5;
import java.util.Scanner;
/**
 *
 * @author PROJET NDAGANO
 */
public class Lectureroom {



    static class LectureRoom {
        private int students;//declaring our integer
        private boolean[] light;// that boolean which will help us to declare if the light in the room is either off or on

        public LectureRoom() {
            this.students = 0;
            this.light = new boolean[3];//actually there is 3 lights in the room,1,2 and 3 lights
        }

        public void addStudents(int num) {
            this.students += num;// here i want to add number of students
        }

        public void removeStudents(int num) {
            this.students = Math.max(0, this.students - num);// here i'm saying that when i remve students in the class the maximum that must remain is 0
        }

        public void turnOnLight(int num) {
            if (num >= 1 && num <= 3) {
                this.light[num - 1] = true;
            }
        }

        public void turnOffLight(int num) {
            if (num >= 1 && num <= 3) {
                this.light[num - 1] = false;
            }
        }

        public void displayStatus() {
            System.out.println("Number of students: " + this.students);
            System.out.println("Light status:");
            for (int i = 0; i < 3; i++) {
                System.out.println("Light " + (i + 1) + ": " + (this.light[i] ? "On" : "Off"));
            }}}}
        
    

    