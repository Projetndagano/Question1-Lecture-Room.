/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package bd.mavenproject5;

import java.util.Scanner;

/**
 *
 * @author PROJET NDAGANO
 */
public class Mavenproject5 {

    public static void main(String[] args) {
        Lectureroom.LectureRoom room = new Lectureroom.LectureRoom();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Main Menu:");
            System.out.println("W: Add students");
            System.out.println("X: Remove students");
            System.out.println("Y: Turn on light");
            System.out.println("Z: Turn off light");
            System.out.println("Q: Quit");
            System.out.println("p: Display status");

            System.out.print("Enter your choice: ");
            String choice = scanner.next().toUpperCase();

            switch (choice) {
                case "W":
                    System.out.print("Enter the number of students to add: ");
                    int num = scanner.nextInt();
                    room.addStudents(num);
                    break;
                case "X":
                    System.out.print("Enter the number of students to remove: ");
                    num = scanner.nextInt();
                    room.removeStudents(num);
                    break;
                case "Y":
                    System.out.print("Enter the light number to turn on (1-3): ");
                    num = scanner.nextInt();
                    room.turnOnLight(num);
                    break;
                case "Z":
                    System.out.print("Enter the light number to turn off (1-3): ");
                    num = scanner.nextInt();
                    room.turnOffLight(num);
                    break;
                case "Q":
                    return;
                case "p":
                    room.displayStatus();
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
    
        
   



    
    
    
    
    
    
    
    
    

